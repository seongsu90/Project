package com.mycompany.ourapp.dto;

public class CouponBox {
	private String cbmid;
	private int cbnumber;
	
	public String getCbmid() {
		return cbmid;
	}
	public void setCbmid(String cbmid) {
		this.cbmid = cbmid;
	}
	public int getCbnumber() {
		return cbnumber;
	}
	public void setCbnumber(int cbnumber) {
		this.cbnumber = cbnumber;
	}

}
