package com.mycompany.ourapp.dto;

public class Pos {
	private int ptableno;
	private int presid;
	private String pmlname;
	private int pcount;
	
	public int getPtableno() {
		return ptableno;
	}
	public void setPtableno(int ptableno) {
		this.ptableno = ptableno;
	}
	public int getPresid() {
		return presid;
	}
	public void setPresid(int presid) {
		this.presid = presid;
	}
	public String getPmlname() {
		return pmlname;
	}
	public void setPmlname(String pmlname) {
		this.pmlname = pmlname;
	}
	public int getPcount() {
		return pcount;
	}
	public void setPcount(int pcount) {
		this.pcount = pcount;
	}
}
