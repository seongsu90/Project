package com.mycompany.ourapp.dto;
public class MenuList {
	private String mlname;
	private int mlprice;
	private int mlresid;
	private String mlinfo;
	private String mlsavedfile;
	private boolean mlishot;
	
	public String getMlname() {
		return mlname;
	}
	public void setMlname(String mlname) {
		this.mlname = mlname;
	}
	public int getMlprice() {
		return mlprice;
	}
	public void setMlprice(int mlprice) {
		this.mlprice = mlprice;
	}
	public int getMlresid() {
		return mlresid;
	}
	public void setMlresid(int mlresid) {
		this.mlresid = mlresid;
	}
	public String getMlinfo() {
		return mlinfo;
	}
	public void setMlinfo(String mlinfo) {
		this.mlinfo = mlinfo;
	}
	public String getMlsavedfile() {
		return mlsavedfile;
	}
	public void setMlsavedfile(String mlsavedfile) {
		this.mlsavedfile = mlsavedfile;
	}
	public boolean getMlishot() {
		return mlishot;
	}
	public void setMlishot(boolean mlishot) {
		this.mlishot = mlishot;
	}
	
	
	
}
