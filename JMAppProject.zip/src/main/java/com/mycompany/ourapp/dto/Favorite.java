package com.mycompany.ourapp.dto;

public class Favorite {
	private String fmid;
	private int fresid;
	
	public String getFmid() {
		return fmid;
	}
	public void setFmid(String fmid) {
		this.fmid = fmid;
	}
	public int getFresid() {
		return fresid;
	}
	public void setFresid(int fresid) {
		this.fresid = fresid;
	}
	
}
